var mod__calculate__global__source_8f90 =
[
    [ "arbitrary_hed_x", "mod__calculate__global__source_8f90.html#a475e284abe75d09e3ee4cdc431cc5dc9", null ],
    [ "arbitrary_hed_y", "mod__calculate__global__source_8f90.html#a6d853bb289bfe11e9df9188bcd569b91", null ],
    [ "dist2segment", "mod__calculate__global__source_8f90.html#a7e28328e9ba2147067a2bfcc123fb23e", null ],
    [ "hed_x", "mod__calculate__global__source_8f90.html#a89032885925ea1acab89af1825197ac0", null ],
    [ "hed_y", "mod__calculate__global__source_8f90.html#ad1922dc3b486c200cf6b18f78fcbd391", null ],
    [ "loop_source", "mod__calculate__global__source_8f90.html#ad860d2870fa56b5412217225d12230e7", null ],
    [ "segmented_source", "mod__calculate__global__source_8f90.html#a829812c226db75c35a1112d56be5a5c3", null ],
    [ "straight_source_segment", "mod__calculate__global__source_8f90.html#a99545b56430468e8b6ebe39f1a8893bb", null ]
];