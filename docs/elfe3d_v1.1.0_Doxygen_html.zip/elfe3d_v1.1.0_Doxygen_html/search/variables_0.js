var searchData=
[
  ['bwrd_273',['bwrd',['../namespacedefine__model.html#a83df186371659053304ed09a54147994',1,'define_model']]]
];
