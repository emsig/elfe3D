var searchData=
[
  ['opencode_298',['opencode',['../namespacedefine__model.html#a52579b8212d17397900fee842f9d0956',1,'define_model']]],
  ['opening_299',['opening',['../namespacedefine__model.html#a15c41816e5fdba26cb54a985aa11a00c',1,'define_model']]]
];
