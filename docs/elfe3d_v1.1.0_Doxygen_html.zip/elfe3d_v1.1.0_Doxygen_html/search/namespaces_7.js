var searchData=
[
  ['solvers_175',['solvers',['../namespacesolvers.html',1,'']]],
  ['sparse_5fmatrix_5foperations_176',['sparse_matrix_operations',['../namespacesparse__matrix__operations.html',1,'']]]
];
