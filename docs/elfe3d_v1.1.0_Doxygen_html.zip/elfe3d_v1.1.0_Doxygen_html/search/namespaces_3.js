var searchData=
[
  ['error_5festimates_168',['error_estimates',['../namespaceerror__estimates.html',1,'']]]
];
