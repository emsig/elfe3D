var searchData=
[
  ['tetr_5fheight_263',['tetr_height',['../namespaceerror__estimates.html#a7690c8d98c8a3fba8d86d497e43792a3',1,'error_estimates']]],
  ['triangle_5farea_264',['triangle_area',['../namespaceerror__estimates.html#a4bf671479bef0a97ab28e182ef3bbee6',1,'error_estimates']]],
  ['triangle_5fdiameter_265',['triangle_diameter',['../namespaceerror__estimates.html#a4494ea8b2ca594929b0cef380068a476',1,'error_estimates']]],
  ['triangle_5fmidpoint_266',['triangle_midpoint',['../namespaceerror__estimates.html#aa8691adb4919346250fa2bfa94517828',1,'error_estimates']]]
];
