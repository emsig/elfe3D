var searchData=
[
  ['tetgen_5foperations_177',['tetgen_operations',['../namespacetetgen__operations.html',1,'']]]
];
