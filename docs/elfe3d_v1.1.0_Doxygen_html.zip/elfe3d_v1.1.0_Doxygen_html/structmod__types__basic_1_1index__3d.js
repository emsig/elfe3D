var structmod__types__basic_1_1index__3d =
[
    [ "ix", "structmod__types__basic_1_1index__3d.html#a2c2e5d1cf818bd54a81971b39b268853", null ],
    [ "iy", "structmod__types__basic_1_1index__3d.html#abc6b65fd30ce739efb1dbca9cbd26b5a", null ],
    [ "iz", "structmod__types__basic_1_1index__3d.html#adb1bad58305fce8f4bf66c944d2feeea", null ]
];