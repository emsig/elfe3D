var namespaces_dup =
[
    [ "bc", "namespacebc.html", [
      [ "apply_bc", "namespacebc.html#a66cb31f7bba2b2fce51a50ad4b5266ac", null ],
      [ "apply_pec_bc", "namespacebc.html#a9435640118b7a2d89705725745460f8a", null ],
      [ "detect_pec_edges", "namespacebc.html#a908312f0df07b7f9a70de1d945ec953d", null ],
      [ "detect_surface_edges", "namespacebc.html#a5f8fc1d7084120f4d5eb0f482e626a7e", null ]
    ] ],
    [ "calculate_global_source", "namespacecalculate__global__source.html", [
      [ "arbitrary_hed_x", "namespacecalculate__global__source.html#a475e284abe75d09e3ee4cdc431cc5dc9", null ],
      [ "arbitrary_hed_y", "namespacecalculate__global__source.html#a6d853bb289bfe11e9df9188bcd569b91", null ],
      [ "dist2segment", "namespacecalculate__global__source.html#a7e28328e9ba2147067a2bfcc123fb23e", null ],
      [ "hed_x", "namespacecalculate__global__source.html#a89032885925ea1acab89af1825197ac0", null ],
      [ "hed_y", "namespacecalculate__global__source.html#ad1922dc3b486c200cf6b18f78fcbd391", null ],
      [ "loop_source", "namespacecalculate__global__source.html#ad860d2870fa56b5412217225d12230e7", null ],
      [ "segmented_source", "namespacecalculate__global__source.html#a829812c226db75c35a1112d56be5a5c3", null ],
      [ "straight_source_segment", "namespacecalculate__global__source.html#a99545b56430468e8b6ebe39f1a8893bb", null ]
    ] ],
    [ "calculate_local_left", "namespacecalculate__local__left.html", [
      [ "calc_mass_matrix", "namespacecalculate__local__left.html#a8eee88248b28ece3fdb996294c03a9d1", null ],
      [ "calc_stiffness_matrix", "namespacecalculate__local__left.html#a9c2e5f98ddd2e6e8abb55fb69a6e4fd7", null ]
    ] ],
    [ "calculate_matrices", "namespacecalculate__matrices.html", [
      [ "calc_connect_matrix", "namespacecalculate__matrices.html#a1f6f0bb1a54eb62e678ddd1d52d67a1b", null ],
      [ "calc_coord_matrices", "namespacecalculate__matrices.html#a3618cf4e9acf88dafd9afdbe4f6b0dc1", null ],
      [ "calc_edge_signs", "namespacecalculate__matrices.html#a646bd850f0f06222273d3f372628ebec", null ]
    ] ],
    [ "calculate_tf", "namespacecalculate__tf.html", [
      [ "calculate_fields", "namespacecalculate__tf.html#a511b7710865446f93b119987c7c74041", null ]
    ] ],
    [ "define_model", "namespacedefine__model.html", [
      [ "define_freq", "namespacedefine__model.html#a9eb273107b4ee07ef186770967a7fe9f", null ],
      [ "define_mesh", "namespacedefine__model.html#afa9fa51a30d9a5c69d3317ac15d38181", null ],
      [ "define_model_size", "namespacedefine__model.html#a7475da9dc86d03e5f3efd460827c066d", null ],
      [ "define_output", "namespacedefine__model.html#a7a5fab0145f9e458e8d5259b3a0c5abb", null ],
      [ "define_pec", "namespacedefine__model.html#a96ded67b5fd947a937c939973fef5ea9", null ],
      [ "define_rec", "namespacedefine__model.html#a3319fbbf48355bf710a9146972d5072f", null ],
      [ "define_refinement", "namespacedefine__model.html#a3272a5481782a13914df2da655abad30", null ],
      [ "define_solver", "namespacedefine__model.html#a2fe30e860a3460bbb0e0122cf49eeef9", null ],
      [ "define_source", "namespacedefine__model.html#a7228d8af7037b5cc7e6c049ced709e98", null ],
      [ "bwrd", "namespacedefine__model.html#a83df186371659053304ed09a54147994", null ],
      [ "ccom", "namespacedefine__model.html#ab458eff06e129a418fc6a10a316b52da", null ],
      [ "ctmp", "namespacedefine__model.html#a7ab0ff8df9149c8c67405585eb8fa5f2", null ],
      [ "ctmpcode", "namespacedefine__model.html#a2315dce40f0fdd28f2e2641cd9522922", null ],
      [ "ewrd", "namespacedefine__model.html#afdb23debf6274a9b6cf7ed73e4ff79e2", null ],
      [ "filename", "namespacedefine__model.html#ab055444fd67f01eb2e3844b7f6d88a32", null ],
      [ "fnl", "namespacedefine__model.html#ae3901e4f80fd72229e8becd9cf12d459", null ],
      [ "in_unit", "namespacedefine__model.html#a2538819c457aaa834d5f49f03318eff0", null ],
      [ "lfm", "namespacedefine__model.html#a3df8bc00fea5ffb22f1a15e9636656af", null ],
      [ "lil", "namespacedefine__model.html#a0e351f6f91cf4a528c024cde2b91be78", null ],
      [ "msl", "namespacedefine__model.html#a82edcda3632e6fb502ed2fb63b63fc5f", null ],
      [ "opencode", "namespacedefine__model.html#a52579b8212d17397900fee842f9d0956", null ],
      [ "opening", "namespacedefine__model.html#a15c41816e5fdba26cb54a985aa11a00c", null ],
      [ "readcode", "namespacedefine__model.html#a94a6cfa73085ec40e65cc8e52d898a31", null ],
      [ "skipcol", "namespacedefine__model.html#a96ca42f3339ef784d0a08755c35a95ba", null ]
    ] ],
    [ "error_estimates", "namespaceerror__estimates.html", [
      [ "calculate_elemental_influence_source", "namespaceerror__estimates.html#ab9329b4cb111e64f4b601a1dbc622363", null ],
      [ "calculate_elemental_residuals", "namespaceerror__estimates.html#acfa04af6237034c485e1bf96c8b5c402", null ],
      [ "calculate_face_jumps", "namespaceerror__estimates.html#a44895bca603b0a11ce9e7acf6461c2b9", null ],
      [ "calculate_face_normal", "namespaceerror__estimates.html#a4ed8981c03c2b8e04b7bf6e08ce7117e", null ],
      [ "compute_elemental_error_estimates", "namespaceerror__estimates.html#afd9b6f23cdd255c841038d8dbf53bb9e", null ],
      [ "find_common_nodes", "namespaceerror__estimates.html#ab988a0caaca647929b9ab35f0890692f", null ],
      [ "tetr_height", "namespaceerror__estimates.html#a7690c8d98c8a3fba8d86d497e43792a3", null ],
      [ "triangle_area", "namespaceerror__estimates.html#a4bf671479bef0a97ab28e182ef3bbee6", null ],
      [ "triangle_diameter", "namespaceerror__estimates.html#a4494ea8b2ca594929b0cef380068a476", null ],
      [ "triangle_midpoint", "namespaceerror__estimates.html#aa8691adb4919346250fa2bfa94517828", null ],
      [ "write_vtk", "namespaceerror__estimates.html#a66839e53bf3b000dab2255f2b3109cdf", null ]
    ] ],
    [ "interp_functions", "namespaceinterp__functions.html", [
      [ "calc_abcd", "namespaceinterp__functions.html#a4b7ef2149db8c314ef09b08b08c376e9", null ],
      [ "calc_edge_length", "namespaceinterp__functions.html#a03ad56f12a94537bc3b0034a8e0f858b", null ],
      [ "calc_vol", "namespaceinterp__functions.html#a8b329decae3e67bc453b1822a407a570", null ]
    ] ],
    [ "mod_constant", "namespacemod__constant.html", [
      [ "d0", "namespacemod__constant.html#a024c7240edee2fd24398f6df183e87e0", null ],
      [ "d1", "namespacemod__constant.html#ad59b13062659f41de12a7408d3ac5e0a", null ],
      [ "d10", "namespacemod__constant.html#a8642e4a1f9ba23f39857eb2bc82d15eb", null ],
      [ "d2", "namespacemod__constant.html#a54f107f80666f14f7eb7fda8d40b0198", null ],
      [ "dp", "namespacemod__constant.html#a0026e774951d4463095ae400ed5f969a", null ],
      [ "eps_dp", "namespacemod__constant.html#a1c958e3491709e4c10e907a7c9bb3dc4", null ],
      [ "epsilon_0", "namespacemod__constant.html#aa79d274d3d15c17a683975622e1b9d32", null ],
      [ "ln_10", "namespacemod__constant.html#ab94dbca8a49cf8260225da555f96c512", null ],
      [ "log_unit", "namespacemod__constant.html#a6e35640a862531b17efe1649313b1bfe", null ],
      [ "logfile_screen", "namespacemod__constant.html#a89529df13a8803100481558133fee79e", null ],
      [ "mu_0", "namespacemod__constant.html#a7d1d66552c839878db00fe6318954c9c", null ],
      [ "pi", "namespacemod__constant.html#a6c42781d1ec56496062039cf5bd5ad91", null ],
      [ "rho_0", "namespacemod__constant.html#a6f5aca62a6ed614c95edbdf4ea74ad86", null ],
      [ "ssp", "namespacemod__constant.html#ad6995b4132bdfb72df01bda9d283d8a6", null ],
      [ "zerow", "namespacemod__constant.html#abde814cac1637ef84950e27e99d6c36e", null ]
    ] ],
    [ "mod_types_basic", "namespacemod__types__basic.html", "namespacemod__types__basic" ],
    [ "mod_util", "namespacemod__util.html", [
      [ "allocheck", "namespacemod__util.html#a51239403b2f58133293ba8c2fd240e10", null ],
      [ "begwrd", "namespacemod__util.html#a9e83d744d508ae832d76ce1ea8669d5a", null ],
      [ "bubblesort_int", "namespacemod__util.html#a6dda0f5f0798efc5360c9752240f24bb", null ],
      [ "bubblesort_real", "namespacemod__util.html#a29f0b0f14ee69a9c0b24bf994dcd9258", null ],
      [ "bubblesort_real_2d", "namespacemod__util.html#afb6b9c031ddfa67a8586cbc61e18c891", null ],
      [ "check_input", "namespacemod__util.html#ab2b04ca3272e24db7e5ceb9cd49aa101", null ],
      [ "check_unknown_input", "namespacemod__util.html#ae4bbadb413882a33e024d2bb5719c1fb", null ],
      [ "endwrd", "namespacemod__util.html#a3e6fec4f9d6a43b58b69a6f26fb691d8", null ],
      [ "findstr", "namespacemod__util.html#a8dbe1c697f83f7e78a43a92a19993c42", null ],
      [ "lower", "namespacemod__util.html#aee534fa40624eec4e22eee63c904b352", null ],
      [ "nword", "namespacemod__util.html#ac8094857282804166f1d4e20fa95c598", null ],
      [ "unique_real", "namespacemod__util.html#a7cf97445c9f74760dd23985c8ece79c4", null ],
      [ "unique_real_2d", "namespacemod__util.html#af0970b73700b05b3a9584e017305ebdf", null ],
      [ "upper", "namespacemod__util.html#a49bfaee7b2484eb62fbf9b594ce057f7", null ],
      [ "write_error_message", "namespacemod__util.html#a944366c41e8a1e719cdaef70ab0524e6", null ],
      [ "write_message", "namespacemod__util.html#a655a8389825604f5e6b7f6880e4e44e0", null ]
    ] ],
    [ "model_parameters", "namespacemodel__parameters.html", [
      [ "read_model_param", "namespacemodel__parameters.html#a88955715d8df5c186cf0cddf063a5706", null ]
    ] ],
    [ "read_mesh", "namespaceread__mesh.html", [
      [ "read_edges", "namespaceread__mesh.html#a304e9ad8018f33c01b7e6482d9775c98", null ],
      [ "read_elements", "namespaceread__mesh.html#ac74569cebd22f7da6653043fb7a41db8", null ],
      [ "read_neigh", "namespaceread__mesh.html#aed051b84fdd9ca69b2f18ae4cfd99029", null ],
      [ "read_nodes", "namespaceread__mesh.html#a38b02f52ad48e2b8ca449e0205bf2ccb", null ]
    ] ],
    [ "solvers", "namespacesolvers.html", [
      [ "mumps_solving", "namespacesolvers.html#a61896acdcedf07ddd93f45dad00e3e56", null ],
      [ "mumps_solving_multiple_rhs", "namespacesolvers.html#af83d49ddc215887b22cbacb18b2ecaae", null ],
      [ "pardiso_solving", "namespacesolvers.html#a9fabc5857c15762597479a6deb44beb8", null ]
    ] ],
    [ "sparse_matrix_operations", "namespacesparse__matrix__operations.html", [
      [ "compcoicsr", "namespacesparse__matrix__operations.html#a7809e79c3c9c3f8dff9d5ab5709f9e47", null ],
      [ "compcsrcoo", "namespacesparse__matrix__operations.html#a13a98bbc20d9b0c91d4ebf645f8e29f5", null ],
      [ "compgetu", "namespacesparse__matrix__operations.html#a2925f383a926f58e9a4046e992bba46f", null ],
      [ "csort", "namespacesparse__matrix__operations.html#afe402d71f0f41edad4edf6983ca87dc0", null ],
      [ "csumdup", "namespacesparse__matrix__operations.html#aa9c05021eee60a9ca832e02a0cd53748", null ]
    ] ],
    [ "tetgen_operations", "namespacetetgen__operations.html", [
      [ "calculate_elemental_volume_constraints", "namespacetetgen__operations.html#a280639f88f9fed34a95af7809a0cf399", null ],
      [ "generate_new_mesh", "namespacetetgen__operations.html#af959642dd43e8b929ec758da3d879204", null ]
    ] ],
    [ "vector_products", "namespacevector__products.html", [
      [ "cross_product", "namespacevector__products.html#a65fdadffad4829228185a11d98baecdc", null ],
      [ "cross_product_real", "namespacevector__products.html#ae68435f64c373159174cc88ab66d56b5", null ]
    ] ]
];