var mod__sparse__matrix__operations_8f90 =
[
    [ "compcoicsr", "mod__sparse__matrix__operations_8f90.html#a7809e79c3c9c3f8dff9d5ab5709f9e47", null ],
    [ "compcsrcoo", "mod__sparse__matrix__operations_8f90.html#a13a98bbc20d9b0c91d4ebf645f8e29f5", null ],
    [ "compgetu", "mod__sparse__matrix__operations_8f90.html#a2925f383a926f58e9a4046e992bba46f", null ],
    [ "csort", "mod__sparse__matrix__operations_8f90.html#afe402d71f0f41edad4edf6983ca87dc0", null ],
    [ "csumdup", "mod__sparse__matrix__operations_8f90.html#aa9c05021eee60a9ca832e02a0cd53748", null ]
];