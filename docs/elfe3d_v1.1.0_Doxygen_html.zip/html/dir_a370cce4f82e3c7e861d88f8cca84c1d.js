var dir_a370cce4f82e3c7e861d88f8cca84c1d =
[
    [ "elfe3d.f90", "elfe3d_8f90.html", "elfe3d_8f90" ],
    [ "mod_BC.f90", "mod___b_c_8f90.html", "mod___b_c_8f90" ],
    [ "mod_calculate_global_source.f90", "mod__calculate__global__source_8f90.html", "mod__calculate__global__source_8f90" ],
    [ "mod_calculate_local_left.f90", "mod__calculate__local__left_8f90.html", "mod__calculate__local__left_8f90" ],
    [ "mod_calculate_matrices.f90", "mod__calculate__matrices_8f90.html", "mod__calculate__matrices_8f90" ],
    [ "mod_calculate_tf.f90", "mod__calculate__tf_8f90.html", "mod__calculate__tf_8f90" ],
    [ "mod_constant.f90", "mod__constant_8f90.html", "mod__constant_8f90" ],
    [ "mod_define_model.f90", "mod__define__model_8f90.html", "mod__define__model_8f90" ],
    [ "mod_error_estimates.f90", "mod__error__estimates_8f90.html", "mod__error__estimates_8f90" ],
    [ "mod_interp_functions.f90", "mod__interp__functions_8f90.html", "mod__interp__functions_8f90" ],
    [ "mod_model_parameters.f90", "mod__model__parameters_8f90.html", "mod__model__parameters_8f90" ],
    [ "mod_read_mesh.f90", "mod__read__mesh_8f90.html", "mod__read__mesh_8f90" ],
    [ "mod_solvers.f90", "mod__solvers_8f90.html", "mod__solvers_8f90" ],
    [ "mod_sparse_matrix_operations.f90", "mod__sparse__matrix__operations_8f90.html", "mod__sparse__matrix__operations_8f90" ],
    [ "mod_tetgen_operations.f90", "mod__tetgen__operations_8f90.html", "mod__tetgen__operations_8f90" ],
    [ "mod_types_basic.f90", "mod__types__basic_8f90.html", [
      [ "point_2d", "structmod__types__basic_1_1point__2d.html", "structmod__types__basic_1_1point__2d" ],
      [ "point_3d", "structmod__types__basic_1_1point__3d.html", "structmod__types__basic_1_1point__3d" ],
      [ "cpoint_3d", "structmod__types__basic_1_1cpoint__3d.html", "structmod__types__basic_1_1cpoint__3d" ],
      [ "loc_2d", "structmod__types__basic_1_1loc__2d.html", "structmod__types__basic_1_1loc__2d" ],
      [ "loc_3d", "structmod__types__basic_1_1loc__3d.html", "structmod__types__basic_1_1loc__3d" ],
      [ "index_2d", "structmod__types__basic_1_1index__2d.html", "structmod__types__basic_1_1index__2d" ],
      [ "index_3d", "structmod__types__basic_1_1index__3d.html", "structmod__types__basic_1_1index__3d" ]
    ] ],
    [ "mod_util.f90", "mod__util_8f90.html", "mod__util_8f90" ],
    [ "mod_vector_products.f90", "mod__vector__products_8f90.html", "mod__vector__products_8f90" ],
    [ "mpif.h", "mpif_8h.html", "mpif_8h" ],
    [ "zmumps_c.h", "zmumps__c_8h.html", "zmumps__c_8h" ],
    [ "zmumps_root.h", "zmumps__root_8h.html", "zmumps__root_8h" ],
    [ "zmumps_struc.h", "zmumps__struc_8h.html", "zmumps__struc_8h" ]
];