var mod__calculate__matrices_8f90 =
[
    [ "calc_connect_matrix", "mod__calculate__matrices_8f90.html#a1f6f0bb1a54eb62e678ddd1d52d67a1b", null ],
    [ "calc_coord_matrices", "mod__calculate__matrices_8f90.html#a3618cf4e9acf88dafd9afdbe4f6b0dc1", null ],
    [ "calc_edge_signs", "mod__calculate__matrices_8f90.html#a646bd850f0f06222273d3f372628ebec", null ]
];