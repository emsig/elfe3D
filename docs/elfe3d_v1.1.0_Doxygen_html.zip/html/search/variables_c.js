var searchData=
[
  ['oct_452',['Oct',['../mpif_8h.html#a320f00f07c26aa461d46218a84a50e4c',1,'Oct():&#160;mpif.h'],['../zmumps__root_8h.html#a320f00f07c26aa461d46218a84a50e4c',1,'Oct():&#160;zmumps_root.h'],['../zmumps__struc_8h.html#a320f00f07c26aa461d46218a84a50e4c',1,'Oct():&#160;zmumps_struc.h']]],
  ['ooc_5fprefix_453',['ooc_prefix',['../struct_z_m_u_m_p_s___s_t_r_u_c___c.html#a122dadf913a33b9e1da76daadf46ee45',1,'ZMUMPS_STRUC_C']]],
  ['ooc_5ftmpdir_454',['ooc_tmpdir',['../struct_z_m_u_m_p_s___s_t_r_u_c___c.html#ac2e54dd78e29c1e07e1f01fb8a30cfae',1,'ZMUMPS_STRUC_C']]],
  ['opencode_455',['opencode',['../namespacedefine__model.html#a52579b8212d17397900fee842f9d0956',1,'define_model']]],
  ['opening_456',['opening',['../namespacedefine__model.html#a15c41816e5fdba26cb54a985aa11a00c',1,'define_model']]]
];
