var searchData=
[
  ['solvers_269',['solvers',['../namespacesolvers.html',1,'']]],
  ['sparse_5fmatrix_5foperations_270',['sparse_matrix_operations',['../namespacesparse__matrix__operations.html',1,'']]]
];
