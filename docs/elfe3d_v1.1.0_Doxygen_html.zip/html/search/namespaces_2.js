var searchData=
[
  ['define_5fmodel_261',['define_model',['../namespacedefine__model.html',1,'']]]
];
