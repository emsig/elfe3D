var searchData=
[
  ['generate_5fnew_5fmesh_87',['generate_new_mesh',['../namespacetetgen__operations.html#af959642dd43e8b929ec758da3d879204',1,'tetgen_operations']]]
];
