var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvwxyz",
  1: "cilpz",
  2: "bcdeimrstv",
  3: "emrz",
  4: "abcdefghlmnprstuwz",
  5: "abcdefijklmnoprstuvwxyz",
  6: "m",
  7: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros",
  7: "Pages"
};

