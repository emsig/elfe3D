var searchData=
[
  ['error_5festimates_262',['error_estimates',['../namespaceerror__estimates.html',1,'']]]
];
