var searchData=
[
  ['segmented_5fsource_359',['segmented_source',['../namespacecalculate__global__source.html#a829812c226db75c35a1112d56be5a5c3',1,'calculate_global_source']]],
  ['straight_5fsource_5fsegment_360',['straight_source_segment',['../namespacecalculate__global__source.html#a99545b56430468e8b6ebe39f1a8893bb',1,'calculate_global_source']]]
];
