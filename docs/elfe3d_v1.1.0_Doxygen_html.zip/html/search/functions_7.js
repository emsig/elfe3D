var searchData=
[
  ['hed_5fx_346',['hed_x',['../namespacecalculate__global__source.html#a89032885925ea1acab89af1825197ac0',1,'calculate_global_source']]],
  ['hed_5fy_347',['hed_y',['../namespacecalculate__global__source.html#ad1922dc3b486c200cf6b18f78fcbd391',1,'calculate_global_source']]]
];
