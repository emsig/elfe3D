var searchData=
[
  ['tetgen_5foperations_271',['tetgen_operations',['../namespacetetgen__operations.html',1,'']]]
];
