var searchData=
[
  ['uns_5fperm_485',['uns_perm',['../struct_z_m_u_m_p_s___s_t_r_u_c___c.html#ae5c4b17e3e81bb3f6860c46ebde1ed3a',1,'ZMUMPS_STRUC_C']]]
];
