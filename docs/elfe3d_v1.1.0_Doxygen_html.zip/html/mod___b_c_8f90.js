var mod___b_c_8f90 =
[
    [ "apply_bc", "mod___b_c_8f90.html#a66cb31f7bba2b2fce51a50ad4b5266ac", null ],
    [ "apply_pec_bc", "mod___b_c_8f90.html#a9435640118b7a2d89705725745460f8a", null ],
    [ "detect_pec_edges", "mod___b_c_8f90.html#a908312f0df07b7f9a70de1d945ec953d", null ],
    [ "detect_surface_edges", "mod___b_c_8f90.html#a5f8fc1d7084120f4d5eb0f482e626a7e", null ]
];