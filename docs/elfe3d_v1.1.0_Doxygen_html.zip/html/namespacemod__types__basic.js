var namespacemod__types__basic =
[
    [ "point_2d", "structmod__types__basic_1_1point__2d.html", "structmod__types__basic_1_1point__2d" ],
    [ "point_3d", "structmod__types__basic_1_1point__3d.html", "structmod__types__basic_1_1point__3d" ],
    [ "cpoint_3d", "structmod__types__basic_1_1cpoint__3d.html", "structmod__types__basic_1_1cpoint__3d" ],
    [ "loc_2d", "structmod__types__basic_1_1loc__2d.html", "structmod__types__basic_1_1loc__2d" ],
    [ "loc_3d", "structmod__types__basic_1_1loc__3d.html", "structmod__types__basic_1_1loc__3d" ],
    [ "index_2d", "structmod__types__basic_1_1index__2d.html", "structmod__types__basic_1_1index__2d" ],
    [ "index_3d", "structmod__types__basic_1_1index__3d.html", "structmod__types__basic_1_1index__3d" ]
];