var structmod__types__basic_1_1loc__2d =
[
    [ "y", "structmod__types__basic_1_1loc__2d.html#ac482cc089270d0c81a75ceea1af24c53", null ],
    [ "z", "structmod__types__basic_1_1loc__2d.html#a4ec49ab7e42eb56f29a43392f501cac9", null ]
];