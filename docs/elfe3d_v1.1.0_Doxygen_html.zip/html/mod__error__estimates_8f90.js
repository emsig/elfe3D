var mod__error__estimates_8f90 =
[
    [ "calculate_elemental_influence_source", "mod__error__estimates_8f90.html#ab9329b4cb111e64f4b601a1dbc622363", null ],
    [ "calculate_elemental_residuals", "mod__error__estimates_8f90.html#acfa04af6237034c485e1bf96c8b5c402", null ],
    [ "calculate_face_jumps", "mod__error__estimates_8f90.html#a44895bca603b0a11ce9e7acf6461c2b9", null ],
    [ "calculate_face_normal", "mod__error__estimates_8f90.html#a4ed8981c03c2b8e04b7bf6e08ce7117e", null ],
    [ "compute_elemental_error_estimates", "mod__error__estimates_8f90.html#afd9b6f23cdd255c841038d8dbf53bb9e", null ],
    [ "find_common_nodes", "mod__error__estimates_8f90.html#ab988a0caaca647929b9ab35f0890692f", null ],
    [ "tetr_height", "mod__error__estimates_8f90.html#a7690c8d98c8a3fba8d86d497e43792a3", null ],
    [ "triangle_area", "mod__error__estimates_8f90.html#a4bf671479bef0a97ab28e182ef3bbee6", null ],
    [ "triangle_diameter", "mod__error__estimates_8f90.html#a4494ea8b2ca594929b0cef380068a476", null ],
    [ "triangle_midpoint", "mod__error__estimates_8f90.html#aa8691adb4919346250fa2bfa94517828", null ],
    [ "write_vtk", "mod__error__estimates_8f90.html#a66839e53bf3b000dab2255f2b3109cdf", null ]
];